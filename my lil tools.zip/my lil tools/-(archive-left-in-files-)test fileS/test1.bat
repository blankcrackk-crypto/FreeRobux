@echo off
title My Lil Tools

:menu
cls
echo ███ ███ ███ ███ ███ ███ ███ ███ ███ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░
echo ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░
echo ░░░ ░░░ ░░░ ░░░ ░░░ ░░░ ░░░ ░░░ ░░░
echo.
echo ========= MENU =========
echo 1. Make Folder
echo 2. SpammerFlood (open lots of tabs)
echo 3. Exit
echo ========================
echo.

set /p choice=Select option:

if "%choice%"=="1" goto makefolder
if "%choice%"=="2" goto spammer
if "%choice%"=="3" exit
goto menu

:makefolder
cls
echo ==== MAKE FOLDER ====
set /p fname=What name:
mkdir "%fname%"
echo Folder "%fname%" created!
pause
goto menu

:spammer
cls
echo ==== SPAMMER FLOOD ====
set /p url=Enter website URL (include https://):
set /p count=How many tabs to open:

echo Opening %count% tabs...

for /l %%i in (1,1,%count%) do (
    start "" "%url%"
)

echo Done!
pause
goto menu