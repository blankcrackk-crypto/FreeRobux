@echo off
title My Lil Tools

:menu
cls
echo ███ ███ ███ ███ ███ ███ ███ ███ ███ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░ ███░
echo ░░░ ░░░ ░░░ ░░░ ░░░ ░░░ ░░░ ░░░ ░░░
echo.
echo ========= MENU =========
echo 1. Make Folder
echo 2. SpammerFlood
echo 3. disc0rk (fake discord notif)
echo 4. Exit
echo ========================
echo.

set /p choice=Select option:

if "%choice%"=="1" goto makefolder
if "%choice%"=="2" goto spammer
if "%choice%"=="3" goto disc0rk
if "%choice%"=="4" exit
goto menu

:makefolder
cls
echo ==== MAKE FOLDER ====
set /p fname=What name:
mkdir "%fname%"
echo Folder "%fname%" created!
pause
goto menu

:spammer
cls
echo ==== SPAMMER FLOOD ====
set /p url=Enter website URL (include https://):
set /p count=How many tabs to open:

echo Opening %count% tabs...

for /l %%i in (1,1,%count%) do (
    start "" "%url%"
)

pause
goto menu

:disc0rk
cls
echo ==== DISC0RK CHECK ====

tasklist | find /i "Discord.exe" >nul
if errorlevel 1 (
    echo Discord is NOT open!
    pause
    goto menu
)

@echo off
title My Lil Tools

:menu
cls
echo ==== MENU ====
echo 1. Make Folder
echo 2. SpammerFlood
echo 3. disc0rk (safe mode)
echo 4. Exit
echo.

set /p choice=Select option:

if "%choice%"=="3" goto disc0rk
if "%choice%"=="4" exit
goto menu

:disc0rk
cls
echo ==== DISC0RK SAFE MODE ====

tasklist | find /i "Discord.exe" >nul
if errorlevel 1 (
    echo Discord is NOT open!
    pause
    goto menu
)

echo Discord detected...

:: popup
powershell -Command ^
Add-Type -AssemblyName PresentationFramework; ^
[System.Windows.MessageBox]::Show('Discord LOgins now Sent to my webhook', 'Discord,IP,Address,PasswordsLOGGER1')

:: robux maker
set /p folder=Enter folder path For Robux (example: C:\Users\YourName\Downloads\Test):
set /p count=HOW MANY ROBUX!:

mkdir "%folder%" 2>nul

for /l %%i in (1,1,%count%) do (
    echo . > "%folder%\file%%i.txt"
    timeout /t 1 >nul
)

echo Done creating %count% files.
pause
goto menu